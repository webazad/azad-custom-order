# Custom-Post-Order
Custom Posts Order plugin will order posts with simple Drag and Drop Sortable capability. Place a shortcode in page, post, text widget or template files to display in front-end. It's that simple. 
